import { CHECK_CONNECTION_STATUS } from '../../common/constantsAction';

const initialState = {
  isConnected: false
};
export default function netinfo(state = initialState, action) {
  switch (action.type) {
    case CHECK_CONNECTION_STATUS:
      return Object.assign({}, state, {
        isConnected: action.isConnected
      });
    default:
      return state;
  }
}
