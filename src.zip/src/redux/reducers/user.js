import {
    SIGNUP_BY_UUID,
    SIGNUP_SUCCESS,
    SIGNUP_FAILURE,
    USER_INFO,
    USER_INFO_SUCCESS,
    USER_INFO_FAILURE
} from '../../common/constantsAction';

const initialState = {
    isFirstTime: true,
    data: [],
    isFetching: false,
    error: false,
    isLogin: false,

    guestData: [],
    guestError: false,
    isGuestPurchase: false,

    resetSuccess: undefined,
};
const user = (state = initialState, action) => {
    switch (action.type) {
        case SIGNUP_BY_UUID:
            return Object.assign({}, state, {
                data: [],
                isFetching: true,
                error: false,
            });
        case SIGNUP_SUCCESS:
            return Object.assign({}, state, {
                isFirstTime: false,
                isFetching: false,
                data: action.data,
                error: false,

                guestData: [],
                isLogin: true,
                isGuestPurchase: false
            });
        case SIGNUP_FAILURE:
            return Object.assign({}, state, {
                data: [],
                isFetching: false,
                error: true
            });
        case USER_INFO:
            return Object.assign({}, state, {
                data: [],
                isFetching: true,
                error: false
            });
        case USER_INFO_SUCCESS:
            return Object.assign({}, state, {
                isFirstTime: false,
                isFetching: false,
                data: action.data,
                error: false,
                guestData: [],
                isLogin: true,
                isGuestPurchase: false
            });
        case USER_INFO_FAILURE:
            return Object.assign({}, state, {
                data: [],
                isFetching: false,
                error: true
            });
        default:
            return state;
    }
};

export default user;
