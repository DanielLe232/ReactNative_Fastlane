import { createStore, applyMiddleware, compose } from 'redux';
import thunk from 'redux-thunk';
import { createLogger } from 'redux-logger';
import reducers from './rootReducer';

const loggerMiddleware = createLogger({
  predicate: (getState, action) => __DEV__
});
const middleWare = applyMiddleware(thunk, loggerMiddleware);

export default function configureStore() {
  // const composition = compose(middleWare, autoRehydrate());
  const store = createStore(reducers, undefined, middleWare);
  return store;
}
