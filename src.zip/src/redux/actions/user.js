import {
    SIGNUP_BY_UUID,
    SIGNUP_SUCCESS,
    SIGNUP_FAILURE,
    USER_INFO,
    USER_INFO_SUCCESS,
    USER_INFO_FAILURE
} from '../../common/constantsAction';
// import I18n from 'react-native-i18n';
// import base64 from 'base-64';
import constApi from '../../common/constApi';
import API from '../../api/baseRequestAPI';
import { ENV } from '../../common/constants';

export const signUpProccessing = () => ({
    type: SIGNUP_BY_UUID
});

export const signUpSuccess = data => ({
    type: SIGNUP_SUCCESS,
    data
});

export const signUpFailure = error => ({
    type: SIGNUP_FAILURE,
    error
});

export const userInfoProcessing = () => ({
    type: USER_INFO
});

export const userInfoSuccess = data => ({
    type: USER_INFO_SUCCESS,
    data
});

export const userInfoFailure = error => ({
    type: USER_INFO_FAILURE,
    error
});

export const signUpByUuid = values => async dispatch => {
    console.log("asdasdasdasdasd");
    const url = `${constApi.SignUpUser}`;
    values.uuid = '268ba934a672ac9ef9285ea207c415b04186f4226457059c69c5e1791fc7e4214d7a1389cf889fcf1c71a97d7d83a02c';
    const body = {
      uuid: values.uuid
    //   language: I18n.locale ? I18n.locale.split('-')[0] : null
    };
    dispatch(signUpProccessing());
    try {
      const response = await API.post({ url, params: { env: ENV }, body });
      const responseJson = await response.json();
      console.log("asdasd", responseJson);
      if(responseJson.errors !== undefined)
        dispatch(signUpFailure(responseJson));
      else
        dispatch(signUpSuccess(responseJson));
  
    } catch (error) {
      dispatch(signUpFailure(error));
    }
};

export async function getUserInfo() {
    const url = `${constApi.SignUpUser}`;
    const body = {
      uuid: '268ba934a672ac9ef9285ea207c415b04186f4226457059c69c5e1791fc7e4214d7a1389cf889fcf1c71a97d7d83a02c'
    };
    try {
        const response = await API.post({ url, params: { env: ENV }, body });
        const responseJson = await response.json();
        console.log("asdasd", responseJson);
        
    
      } catch (error) {
        console.log("asdasd", error);
      }
}
