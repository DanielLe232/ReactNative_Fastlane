import { CHECK_CONNECTION_STATUS } from '../../common/constantsAction'
// import {updateOfflineLectureStatus} from '../actions/lecture'

const updateConnectionStatus = status => (dispatch, getState) => {
  dispatch({ type: CHECK_CONNECTION_STATUS, isConnected: status });

  //Update lecture status when app become online
  const { user: {data: {id} } } = getState(); // get user id when non - guest mode
  let userID = id; 
  if(id === undefined){
    const { user: {guestData: {id} } } = getState(); //get user id when guest mode
    userID = id
  }
  if(status && userID !== undefined) {
    // dispatch(updateOfflineLectureStatus())
  }
};

export default updateConnectionStatus;
