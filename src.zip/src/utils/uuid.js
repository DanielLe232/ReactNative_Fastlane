import AsyncStorage from '@react-native-community/async-storage';
import { USER_ID } from '../common/constantsAction';

export const getUUID = () => {
  let uuid = 'asdasd';
  uuid = '268ba934a672ac9ef9285ea207c415b04186f4226457059c69c5e1791fc7e4214d7a1389cf889fcf1c71a97d7d83a02c';
  return uuid;
}

export const saveUserId = async userId => {
  try {
    await AsyncStorage.setItem(USER_ID, userId);
  } catch (error) {
    console.log(error.message);
  }
}

export const getUserId = async () => {
  let userId = undefined;
  try {
    userId = await AsyncStorage.getItem(USER_ID) || undefined
  } catch (error) {
    // Error retrieving data
    console.log(error.message);
  }
  return userId;
}

export const removeUserId = async () => {
  try {
    await AsyncStorage.removeItem(USER_ID);
  } catch (error) {
    // Error retrieving data
    console.log(error.message);
  }
}

