import React, { Component } from 'react';
import {
    Text,
    StatusBar,
    View,
    StyleSheet,
    Platform,
    Image,
    TouchableOpacity,
    ViewPropTypes,
    SafeAreaView
} from 'react-native';
import PropTypes from 'prop-types';

export default class Base extends Component {
    static propTypes = {
        styleBar: ViewPropTypes.style,
        showBackButton: PropTypes.bool,
        showXButton: PropTypes.bool,
        onback: PropTypes.func,
        showDownButton: PropTypes.bool,
        downButtonStyle: PropTypes.string,
    };

    goBack = async () => {
        Actions.pop();
        statusBar.dark()
    };

    renderContent() {
        return (
            <View>
                <Text>Please override!</Text>
            </View>
        );
    }

    render() {
        return (
          <SafeAreaView style={[styles.container, { ...this.props.styleBar }]}>
            <View style={styles.parentContent}>
              {this.renderContent()}
              
              {/* {this.props.showBackButton === true ? (
                <TouchableOpacity
                  style={styles.wrapArrowLeft}
                  onPress={this.props.onback ? this.props.onback : this.goBack}>
                  <Image source={arrowLeft} style={styles.arrowLeft} />
                </TouchableOpacity>
              ) : null}
              {this.props.showXButton === true ? (
                <TouchableOpacity
                  style={styles.wrapClosedLeft}
                  onPress={this.props.onback ? this.props.onback : this.goBack}
                >
                  <Image source={closedLeft} style={styles.closedLeft} />
                </TouchableOpacity>
              ) : null}
              {this.props.showDownButton === true ? (
                <TouchableOpacity style={styles.wrapClosedDown} onPress={this.props.onback ? this.props.onback : this.goBack}>
                    {this.props.downButtonStyle === 'white' ?
                      <Image source={navigationDownWhite} style={styles.closedDown} /> :
                      <Image source={navigationDownBlack} style={styles.closedDown} /> 
                    }
                </TouchableOpacity>
              ) : null} */}
              
            </View>
          </SafeAreaView>
        );
      }
}

const styles = StyleSheet.create({
    container: {
      backgroundColor: 'transparent',
      flex: 1
    },
    parentContent: {
      flex: 1
    }
  });
