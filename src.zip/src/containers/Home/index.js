import React, { Component } from 'react';
import {
    StyleSheet,
    Text,
    View,
    SectionList,
    Alert,
    FlatList,
    ActivityIndicator,
    ImageBackground
} from 'react-native';
import Base from '../Base';
import {
    handleAndroidBackButton,
    removeAndroidBackButtonHandler,
    exitAlert
} from '../../common/androidBackButton';
import HeaderHome from './HeaderHome';
import { Category } from '../index';
import BaseStyles from '../../common/baseStyles'
import ItemCard from './ItemCard'
import API from '../../api/baseRequestAPI'
import constApi from '../../common/constApi'
import { getUserId } from '../../utils/uuid'


class Home extends Base {

    constructor(props) {
        super(props)

        this.state = {
            dataSection: [],
            dataRecommend: [],
            dataMyCourse: [],
            dataCategories: {},
            linkCover: '',
            linkBg: '',
            isLoading: false
        };
    }

    async componentDidMount() {
        handleAndroidBackButton(exitAlert);
        const objImage = await this.getAppImage();
        const myCourses = await this.getMyCourses();
        const recommendCourses = await this.getRecommend();
        const categories = await this.getCategories();

        var cover = objImage.find(obj => {
            return obj.meta == 'cover'
        })
        var bg = objImage.find(obj => {
            return obj.meta == 'background'
        })

        const sectionRecommend = {
            title: 'オススメのコース',
            data: recommendCourses.courses
        }
        const sectionMyCourse = {
            title: BaseStyles.categoryMyCourse,
            data: myCourses.courses
        }

        const arrayData = [
            sectionRecommend,
            sectionMyCourse,
        ];

        this.setState({
            linkCover: cover.image_url,
            linkBg: bg.image_url,
            dataCategories: categories,
            dataSource: arrayData,
            isLoading: true
        })
    }

    componentWillUnmount() {
        removeAndroidBackButtonHandler();
    }

    getAppImage = async() => {
        const url = `${constApi.appImage}`;
        const userID = await getUserId();
        const params = {
        };
        try {
            const response = await API.get({ url, userID, params });
            const responseJson = await response.json();
            return responseJson.data
        } catch (error) {
            console.log("asdasd", error);
        }
    }

    getRecommend = async() => {
        const url = `${constApi.recommendCourse}`;
        const userID = await getUserId();
        const params = {
        };
        try {
            const response = await API.get({ url, userID, params });
            const responseJson = await response.json();
            return responseJson.data
        } catch (error) {
            console.log("asdasd", error);
        }
    }

    getMyCourses = async() => {
        const url = `${constApi.myCourse}`;
        const userID = await getUserId();
        const params = {
        };
        try {
            const response = await API.get({ url, userID, params });
            const responseJson = await response.json();
            return responseJson.data
        } catch (error) {
            console.log("asdasd", error);
        }
    }

    getCategories = async() => {
        const url = `${constApi.allCategories}`;
        const userID = await getUserId();
        const params = {
        };
        try {
            const response = await API.get({ url, userID, params });
            const responseJson = await response.json();
            return responseJson.data
        } catch (error) {
            console.log("asdasd", error);
        }
    }

    GetSectionListItem = item => {
        Alert.alert(item);
    };

    FlatListItemSeparator = () => {
        return (
            //Item Separator
            <View style={{ height: 0.5, width: '100%', backgroundColor: '#C8C8C8' }} />
        );
    };

    renderItem = ({ item }) => {
        console.log(item)
        return (
            <View style={styles.SectionListItemStyle}>
                <FlatList
                    horizontal={true}
                    data={item}
                    renderItem={({ item }) => (
                        <View style={styles.containerList}>
                            <Text>aasdasd</Text>
                        </View>

                    )}
                    showsHorizontalScrollIndicator={false}
                    keyExtractor={(item, index) => index.toString()}
                />
            </View>

        );

    };

    renderHeaderItem = ({ section }) => {
        return (
            <Text style={styles.SectionHeaderStyle}> {section.title} </Text>
        );
    };

    render() {
        if (!this.state.isLoading) {
            return <ActivityIndicator size="large" color={BaseStyles.blue} style={{ flex: 1 }} />
        }
        const urlBg = this.state.linkBg;
        return (
            <ImageBackground
                style={styles.bgImage}
                source={{ uri: urlBg }}>
                <View style={styles.container}>
                    {/*  view left  */}
                    <View style={styles.viewLeft}>
                        <Category dataCategories={this.state.dataCategories}/>
                    </View>
                    {/* view right */}
                    <View style={styles.viewRight}>
                        <View style={styles.headerTop}>
                            <HeaderHome linkCover={this.state.linkCover} />
                        </View>
                        <View style={styles.contentList}>
                            <SectionList
                                ItemSeparatorComponent={this.FlatListItemSeparator}
                                sections={this.state.dataSource}
                                renderSectionHeader={this.renderHeaderItem.bind(this)}
                                renderItem={this.renderItem.bind(this)}
                                keyExtractor={(item, index) => index}
                            />
                        </View>
                    </View>
                </View>
            </ImageBackground>
        );
    }
}

const styles = StyleSheet.create({
    bgImage: {
        flex: 1,
        width: '100%',
        height: '100%',
        resizeMode: 'cover'
    },
    container: {
        flex: 1,
        backgroundColor: 'transparent',
        alignSelf: 'center',
        flexDirection: 'row',
    },
    viewLeft: {
        width: BaseStyles.widthMenuLeft,
        backgroundColor: 'transparent',
    },
    viewRight: {
        flex: 1,
        backgroundColor: 'transparent',
    },
    headerTop: {
        height: 130,
    },
    contentList: {
        flex: 1,
        backgroundColor: 'transparent',
    },
    SectionHeaderStyle: {
        backgroundColor: 'transparent',
        fontSize: 20,
        padding: 10,
        color: '#fff',
    },
    SectionListItemStyle: {
        alignItems: 'center',
        fontSize: 15,
        width: 150,
        height: 150,
        color: '#000',
        backgroundColor: 'transparent',
    },
    imageThumbnail: {
        justifyContent: 'center',
        height: 150,
    },
    containerList: {
        width: 150,
        height: 150,
        padding: 5,
        backgroundColor: 'red',
    },
});

export default Home;