import React, {Component} from 'react'
import {
    View, Image, StyleSheet
} from 'react-native'

export default class HeaderHome extends Component {
    constructor(props) {
        super(props)
    }

    render() {
        const url = this.props.linkCover
        return (
            <View style={styles.container}>
                <Image 
                style={styles.backgroundImage}
                source={{uri: url}}
                />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1 
    },
    backgroundImage: {
        width: '100%',
        height: '100%',
        resizeMode: 'cover'
    }
});
