import React, { Component } from 'react'
import PropTypes from 'prop-types'
import {
    StyleSheet,
    View,
    TouchableWithoutFeedback,
    Alert,
    Image,
    Text
} from 'react-native'
import BaseStyles from '../../common/baseStyles'

export default class ItemCard extends Component {
    constructor(props) {
        super(props)
        this.state = {
            isFocus: false
        };

        this.onFocusItem = this.onFocusItem.bind(this)
    }

    onFocusItem() {
        const focus = this.state.isFocus;
        this.setState({
            isFocus: !focus
        });
        if (this.state.isFocus) {
            Alert.alert("focus")
        } else {
            console.log("Connection type", state.type);
        }
    }

    render() {
        return (
            <TouchableWithoutFeedback style={styles.container}
                onFocus={this.onFocusItem}>
                <View style={styles.container}>
                    <Image style={styles.viewImage}></Image>
                    <View style={styles.viewText}>
                        <Text style={styles.viewTitle}>
                            asdasdasd
                            {'\n'}
                            asdasdas
                        </Text>
                        <View style={styles.viewRow}>
                            <Text style={styles.viewCount}>asdasd</Text>
                            <Text style={styles.viewPrice}>2132 $</Text>
                        </View>
                    </View>
                </View>
            </TouchableWithoutFeedback>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        width: BaseStyles.widthItemCard,
        height: BaseStyles.heightItemCard,
        backgroundColor: 'red',
        margin: 5
    },
    viewText: {
        // flex: 1,
        margin: 5,
        backgroundColor: 'yellow'
    },
    viewImage: {
        width: BaseStyles.widthItemCard,
        height: 150,
        resizeMode: 'cover',
        backgroundColor: 'red'
    },
    viewTitle: {
        fontSize: 12
        
        // numberOfLines: 2,
        // ellipsizeMode: 'tail'
    },
    viewRow: {
        // flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    viewCount: {
        fontSize: 10,
        color: 'black'
    },
    viewPrice: {
        fontSize: 12,
        color: 'black'
    }
});