import React, { Component } from 'react';
import { StyleSheet, Text, View, Image } from 'react-native';
import Base from '../Base';
import { Actions } from 'react-native-router-flux';



class Splash extends Base {

    constructor(props) {
        super(props)
    
        this.state = {
             
        }
    }

    componentDidMount = () => {
        setTimeout( () => {
            Actions.replace("home");
         },1000);
    }

    renderContent() {
        return (
            <View style={styles.container}>
                <Image
                    style={styles.backgroundImage}
                    source={require('../../resources/images/splash_screen.png')} 
                />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
    },
    backgroundImage: {
        width: '100%', 
        height: '100%'
    }
});

export default Splash;