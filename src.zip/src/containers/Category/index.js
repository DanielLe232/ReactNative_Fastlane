import React, { Component } from 'react';
import {
    StyleSheet,
    Text,
    View,
    FlatList,
    Image,
    TouchableOpacity
} from 'react-native';
import Base from '../Base';
import BaseStyles from '../../common/baseStyles'

class Category extends Base {

    constructor(props) {
        super(props);
        this.state = {

        }
    }

    focusItem = (item) => {
        console.log('focus item', item)
    }

    blurItem = (item) => {
        console.log('blur item', item)
    }

    pressItem = (item) => {
        console.log('press item', item)
    }

    renderItem = ({ item, index }) => {
        if (item.title == "") {
            return (
                < View style={styles.viewLine} >
                    <View style={styles.itemLine} />
                </ View>
            );
        }
        return (
            < View style={styles.viewList}>
                <TouchableOpacity
                onFocus= {this.focusItem}
                onBlur= {this.blurItem}
                onPress= {this.pressItem} 
                >
                    <Text style={styles.viewText}>{item.title}</Text>
                </TouchableOpacity>
            </View>
        );
    }

    makeCategoriesObject = (title) => {
        return {
            "id": 0,
            "url": title,
            "title": title,
            "summary": title,
            "position": 0
        }
    }

    renderContent() {
        let data = []
        data.push(this.makeCategoriesObject(BaseStyles.categoryTop))
        data.push(this.makeCategoriesObject(BaseStyles.categoryMyCourse))
        data.push(this.makeCategoriesObject(""))
        this.props.dataCategories.forEach(function (element) {
            data.push(element);
        })
        data.push(this.makeCategoriesObject(""))
        data.push(this.makeCategoriesObject(BaseStyles.categoryNotificationHelp))
        data.push(this.makeCategoriesObject(BaseStyles.categoryTermOfUse))
        // const data = this.props.dataCategories
        console.log(data)
        return (
            <View style={styles.container}>
                <Image
                    style={styles.imageTop}
                    source={require('../../resources/images/logo.png')}
                />
                <FlatList
                    data={data}
                    renderItem={this.renderItem}
                    showsVerticalScrollIndicator={false}
                    keyExtractor={(item, index) => index.toString()}
                    contentContainerStyle={styles.listView}
                />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: BaseStyles.blue,
        alignItems: 'center'
    },
    imageTop: {
        width: '60%',
        resizeMode: 'center'
    },
    viewList: {
        height: 40,
        alignItems: 'flex-start',
        justifyContent: 'center',
        // backgroundColor: 'blue',
    },
    viewLine: {
        height: 30,
        width: BaseStyles.widthMenuLeft - 100,
        alignItems: 'center',
        justifyContent: 'center',
        // backgroundColor: 'red'
    },
    itemLine: {
        height: 1,
        width: '100%',
        backgroundColor: 'white',
    },
    listView: {
        flexGrow: 1,
        justifyContent: 'center',
        alignSelf: 'center',
        backgroundColor: 'transparent',
    },
    viewText: {
        fontWeight: '500',
        fontSize: 14,
        textAlign: 'left',
        color: BaseStyles.textCategories,
        backgroundColor: 'transparent',
    }
});

export default Category;