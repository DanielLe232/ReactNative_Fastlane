import Home from '../containers/Home';
import Category from '../containers/Category';
import Splash from '../containers/Splash';
import MyCourse from '../containers/MyCourse'

export {
    Home,
    Category,
    Splash,
    MyCourse
};