import React, { Component } from 'react'
import Base from '../Base'
import { StyleSheet } from 'react-native';

export default class MyCourse extends Base {
    renderContent() {

    }
}

const styles = StyleSheet.create({
});
