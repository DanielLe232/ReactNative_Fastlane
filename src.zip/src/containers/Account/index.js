import React, { Component } from 'react'
import Base from '../Base'

export default class Account extends Base {
    renderContent() {

    }
}

const styles = StyleSheet.create({
});
