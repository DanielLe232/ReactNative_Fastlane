import React, { Component } from 'react';
import {
    Text,
    AppState,
    StyleSheet
} from 'react-native';
import NetInfo from "@react-native-community/netinfo";
import setupI18n from '../common/locales';
import {
    Home,
    Category
} from '../containers';
import IdleTimerManager from 'react-native-idle-timer';
import { Scene, Router, Stack } from 'react-native-router-flux';
import SplashScreen from 'react-native-splash-screen';
import API from '../api/baseRequestAPI'
import constApi from '../common/constApi'
import { ENV } from '../common/constants'
import { getUUID, saveUserId } from '../utils/uuid'

// setup language
setupI18n();
// check network
NetInfo.addEventListener(state => {
    console.log("Connection type", state.type);
    console.log("Is connected?", state.isConnected);
});

export default class Root extends React.PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            appState: AppState.currentState
        };
    }

    signUpUserInfo = async () => {
        const url = `${constApi.SignUpUser}`;
        const body = {
            uuid: getUUID()
        };
        try {
            const response = await API.post({ url, params: { env: ENV }, body });
            const responseJson = await response.json();
            if (responseJson.errors !== undefined)
                if (responseJson.data !== undefined) {
                    saveUserId(responseJson.data.user_id);
                }
                else
                    console.log("asdasd", responseJson);

        } catch (error) {
            // dispatch(signUpFailure(error));
        }
    }

    componentDidMount() {
        if (Text.defaultProps == null) {
            Text.defaultProps = {};
            Text.defaultProps.allowFontScaling = false;
        }
        SplashScreen.hide();
    }

    componentWillMount() {
        IdleTimerManager.setIdleTimerDisabled(true);
        console.log('rooot');
        this.signUpUserInfo()
    }

    render() {
        return (
            <Router>
                <Stack key="root" hideNavBar>
                    <Scene
                        key="home"
                        component={Home}
                    />
                    <Scene
                        key="categories"
                        component={Category}
                    />
                </Stack>
            </Router>
        );
    }
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center'
    }
});
