
function getQueryString(params) {
    const esc = encodeURIComponent;
    return Object.keys(params)
      .map(k => `${esc(k)}=${esc(params[k])}`) 
      .join('&');
  }
  
  function request(data) {
    const method = data.method || 'GET';
    let params = '';
    const headers = {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      'app-api-key': '3pJeS2EkKDfxlqW5DlTAjC48LEWOxD5xI3ehdtmzpHSIzpQj',
      'user-id': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJkYXRhIjo2MDExN30.ojNt4Z_LmU1LD1NmVEYbyBYS3o3L-4cKKkL3qmWqLGk',//data.userID ? `${data.userID}` : '',
      Authorization: `Basic ${data.credential}`
    };
    params = `?${getQueryString(data.params)}`;
    const body = JSON.stringify(data.body);
    const url = data.url + params;
    return fetch(url, { method, headers, body });
  }
  
  const API = {
    get: data => request(Object.assign({ method: 'GET' }, data)),
    post: data => request(Object.assign({ method: 'POST' }, data)),
    put: data => request(Object.assign({ method: 'PUT' }, data)),
    delete: data => request(Object.assign({ method: 'DELETE' }, data)),
    patch: data => request(Object.assign({ method: 'PATCH' }, data))
  };
  
  export default API;
  