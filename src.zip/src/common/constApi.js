import { ACT_API_URL } from './constants';

const URL = {
    // User info
    UserInfor: `${ACT_API_URL}/users/leonet_user`,
    SignUpUser: `${ACT_API_URL}/users/leonet_signup`,

    // app image
    appImage: `${ACT_API_URL}/app_images`,

    // categories
    allCategories:      `${ACT_API_URL}/categories`,
    // get course by categories
    ///categories/:category-id/courses

    // courses
    recommendCourse:    `${ACT_API_URL}/courses/recommended`,
    courseTopHome:     `${ACT_API_URL}/courses/display_on_home_screen`, 
    myCourse:           `${ACT_API_URL}/my_courses`, 
    

};

export default URL;
