import { Dimensions, Platform } from 'react-native';

export const getDeviceWidth = () => {
    const width = Dimensions.get('screen').width
    return width
}

export const getDeviceHeight = () => {
    const height = Dimensions.get('screen').height
    return height
}

const Variables = {
    // item card
    widthItemCard: 215,
    heightItemCard: 200,
    deviceWidth: getDeviceWidth(),
    deviceHeight: getDeviceHeight(),
    widthMenuLeft: 280,

    // color
    blue: '#31859c',
    textCategories: '#BBFFFFFF',


    // Categories
    categoryTop: 'TOP',
    categoryMyCourse: 'マイコース',
    categoryNotificationHelp: 'すべてのコース',
    categoryTermOfUse: 'アカウント設定',
}

export const activityIndicatorView = {
    // alignSelf: 'center',
    flex: 1,
    // justifyContent: 'center',
    // alignItems: 'center',
    // alignContent: 'center'
}



export default Variables;