import I18n from 'react-native-i18n';
import * as localeUtil from '../utils/locale';

export function getDate(time) {
    var createAt = new Date(time)
    var date = createAt.getDate()
    var month = createAt.getMonth() + 1 //because start at 0
    var year = createAt.getFullYear()
    if (localeUtil.isVi())
        return `${date}/${month}/${year}`
    else if (localeUtil.isEn())
        return `${month}/${date}/${year}`
    else
        return `${year}年${month}月${date}日`
}
export function textGoToLecture(id) {
    if (localeUtil.isVi())
        return `Đi đến bài dạy ${id}`;
    else if (localeUtil.isEn())
        return `Go to Lecture ${id}`;
    else
        return `レクチャー${id}を受講する`;
}
export function myCourseProgressing(processing, count) {
    if (localeUtil.isVi())
        return `${processing}/${count} bài giảng đã hoàn thành`;
    else if (localeUtil.isEn())
        return `Finished ${processing}/${count} Lectures`;
    else
        return `${processing}/${count}のレクチャーが完了しました`;
}
export function getInstructor(isLogin, item) {
    if (isLogin) {
        return item.instructor_name
    }
    else {
        if (localeUtil.isVi())
            return item.instructor_name_vi;
        else if (localeUtil.isEn())
            return item.instructor_name_en;
        else
            return item.instructor_name_ja;
    }

}
export function getTitleByLanguage(isLogin, item) {
    if (isLogin) {
        return item.title
    }
    else {
        if (localeUtil.isVi())
            return item.title_vi;
        else if (localeUtil.isEn())
            return item.title_en;
        else
            return item.title_ja;
    }

}
export function getCommentCount(num) {
    if (localeUtil.isJa())
        return `${num} 件`
    else
        return `(${num})`
}

export function resetLanguage() {
    I18n.reset()
    I18n.locale = 'vi'
}

export default function setupI18n(locale_id) {
    I18n.translations = locales;
    I18n.fallbacks = true;
    if (locale_id === 1)
        I18n.locale = 'ja'
    else if (locale_id === 2)
        I18n.locale = 'vi'
    else if (locale_id === 3)
        I18n.locale = 'en'

}
export function getCurrencyUnit(number) {
    if (localeUtil.isVi())
        return `${number} đ`
    else if (localeUtil.isEn())
        return `${number} usd`
    else
        return `${number}円`
}

export function localeUtilDiscount(number) {
    if (localeUtil.isVi())
        return `${number}%OFF`
    else if (localeUtil.isEn())
        return `${number}%OFF`
    else
        return `${number}%引き`
}
export function getLocale() {
    if (localeUtil.isVi())
        return 'vi'
    else if (localeUtil.isEn())
        return 'en'
    else
        return 'ja'
}

export const locales = {
    ja: {
        free: '無料'

    },
    en: {
        free: 'Free'

    },
    vi: {
        free: 'Miễn phí'

    }
};