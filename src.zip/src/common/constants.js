/* global __DEV__ */
import * as localeUtil from '../utils/locale';

let ACT_API_HOST = 'lschool-staging.share-wis.com';
let env = 'staging';

const ACT_API_BASE_PATH = '/api/v7';
const actApiKey = '3pJeS2EkKDfxlqW5DlTAjC48LEWOxD5xI3ehdtmzpHSIzpQj';

export const ACT_API_URL = `https://${ACT_API_HOST}${ACT_API_BASE_PATH}`;
export const ACT_API_KEY = actApiKey;

export const API_ROOT = ACT_API_URL;

export const ACT_SITE_URL = `https://${ACT_API_HOST}`;
export const ACT_INQUIRIES_URL = `https://support.share-wis.com/${localeUtil.getKayakoLocale()}/conversation/new`;
export const ACT_TOS_URL = `${ACT_SITE_URL}/tos`;
export const ACT_PRIVACY_URL = `${ACT_SITE_URL}/privacy`;
export const ACT_PASSWORD_REMINDER_URL = `${ACT_SITE_URL}/users/password/new`;
export const ACT_PRO_COURSES_URL = `${ACT_SITE_URL}/pro_courses`;

export const GOOGLE_CLIENT_ID = __DEV__
  ? '545598168969-jqlphohfjj056kpr7hhj9fqfv8fbrve8.apps.googleusercontent.com'
  : '545598168969-jqlphohfjj056kpr7hhj9fqfv8fbrve8.apps.googleusercontent.com';  
  

// Set 1h of caching (in ms)
export const ACT_API_CACHE = 60 * 60 * 1000;

export const ENV = env;

// check image link exist
export const getUrlImage = (link) => {
  const pattern = /^(f|ht)tps?:\/\//;
  let url
  if (!pattern.test(link)) {
      url = ACT_SITE_URL + link;
   }
   return url
}




